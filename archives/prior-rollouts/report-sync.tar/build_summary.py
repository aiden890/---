"""Build the manifest from actual stats and verify copied MP4 hashes."""
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parent
version = dict(model='XiaomiRobotics/Xiaomi-Robotics-1-RoboCasa365', checkpoint_revision='3a6d0293bfa90759d34a7fc48c2c62413cd7bcf4', code_commit='0dd7aef8dc87296246aae812a1f59ccb708e5546', robocasa_commit='4f8a2980def75a55dff96b990745b83540425f09', inference_image='xiaomi-cu121:t_9f03a613', inference_image_id='sha256:aac5e8e597636dc80df55a3150da68f2fb5897e28bfb02836319578fba477c87', client_image='xiaomi-client:t_9f03a613', client_image_id='sha256:c52e01c1048c46fe0fef0ed535fad3b5067f97b3d5fc397e92a8e96f9702cd19', cuda='12.1.1', torch='2.5.1+cu121', driver='535.183.01', gpu='RTX 3090 24 GB', asset_volume='robocasa-assets-t_5af7225b')
selection = {
'TurnOnSinkFaucet': ('Atomic single-fixture actuation baseline to contrast with multi-subgoal failures.', ['Turn faucet on.']),
'PrepareCoffee': ('Composite-Seen transfer followed by appliance activation; tests prerequisite completion before pressing start.', ['Pick mug from initially open cabinet.', 'Place mug under dispenser.', 'Press start button and release.']),
'KettleBoiling': ('Composite-Seen object placement plus matching burner activation; positive comparison against failed composites.', ['Move kettle from counter onto burner.', 'Turn that burner on and release.']),
'HeatKebabSandwich': ('Composite-Unseen two-object prerequisite followed by door and timer operations; omission/order-sensitive task.', ['Place kebab AND baguette on toaster-oven rack (either pickup order).', 'Close door.', 'Set timer to at least 0.1.']),
'WaffleReheat': ('Composite-Unseen nested-object transport plus door and power sequence.', ['Open microwave.', 'Place bowl containing waffle inside.', 'Close door.', 'Turn microwave on.'])}
analysis = {
'faucet-02': dict(taxonomy=None, diagnosis='Environment-reported success; atomic positive control. No failure diagnosis.'),
'coffee-01': dict(taxonomy='ambiguous', secondary_hypothesis='control/execution', failure_window_steps=[444,1800], diagnosis='Sampled frames show mug pickup, transport toward dispenser (roughly steps 148-444), then prolonged interaction around machine/button (steps 518-1800). No clear omitted subgoal. Exact failed success predicate is not logged; pressing/placement control failure is plausible, but perception/grounding cannot be excluded.'),
'kettle-01': dict(taxonomy=None, diagnosis='Environment-reported success; composite positive comparison.'),
'kebab-01': dict(taxonomy='planning', status='planning-failure candidate', failure_window_steps=[336,784], failure_window_video_seconds=[8.4,19.6], diagnosis='Kebab is carried toward the oven first; baguette remains visibly on the blue plate. By sampled steps 336-448 the door is closed and the arm subsequently attends to door/timer region through step 784. Baguette remains on plate at late sampled steps 1792-2700. Observable omission: proceeds to later appliance subgoals without transporting the second required food. This is an external behavioral classification, not proof of an internal planning defect; missed-object grounding remains an alternative.', reproduction='Different simulation seed 15 also fails but attempts BOTH foods, with visible placement/door difficulty. The same omission was NOT reproduced; do not label reproduced planning failure.'),
'kebab-02': dict(taxonomy='control/execution', confidence='provisional visual diagnosis', failure_window_steps=[448,2700], diagnosis='Unlike seed14, seed15 picks up baguette first (steps112-336) and later kebab (steps896-1008). Baguette is visibly placed on/near the open door rather than securely on a rack (steps448-672), followed by prolonged placement/door interactions. The two-food omission is not reproduced. Exact contact predicates are not logged; grounding ambiguity remains.'),
'waffle-01': dict(taxonomy='ambiguous', secondary_hypothesis='control/execution', failure_window_steps=[1008,4050], diagnosis='Sampled steps168-336 show open-door approach; steps504-840 show bowl transfer and door manipulation; steps1008 onward show prolonged microwave-front/button-region interaction. Broad intended order appears present. Final failure may involve placement, closure or activation; no predicate trace separates these. Do not claim a planning failure.')}
verified = json.loads((root/'video-verification.json').read_text())
by_video = {r['path']:r for r in verified}
rows=[]
for config in sorted(root.glob('*/*/config.json')):
    cfg=json.loads(config.read_text()); attempt=cfg['attempt']
    stats_paths=list(config.parent.glob('rollout/*/stats.json'))
    if not stats_paths:
        assert attempt == 'faucet-01'
        log=(config.parent/'rollout.log').read_text()
        assert 'Read-only file system' in log
        rows.append(dict(**cfg, phase='environment construction', episode_completed=False, seed=None, steps=0, success=None, termination_reason='environment/interface error before episode reset', instruction=None, mp4=None, taxonomy='environment/interface', diagnosis='Upstream MJCFObject writes temporary XML next to object assets (objects.py:244-265). Initial read-only parent asset mount rejected this write. Child-scoped writable clone fixed exact task without changing policy. Error log and original runner preserved.', config=str(config.relative_to(root)), log=str((config.parent/'rollout.log').relative_to(root))))
        continue
    assert len(stats_paths)==1
    stats=json.loads(stats_paths[0].read_text()); assert len(stats['episodes'])==1
    ep=stats['episodes'][0]
    videos=list(stats_paths[0].parent.glob('*.mp4')); assert len(videos)==1
    video=videos[0]; rel=str(video.relative_to(root)); v=by_video[rel]
    assert video.stat().st_size==v['bytes'] and hashlib.sha256(video.read_bytes()).hexdigest()==v['sha256']
    assert (v['seed'], v['steps'], v['success'])==(ep['seed'],ep['steps'],ep['success'])
    assert v['decoded_frames']==ep['steps']//2+1+(ep['steps']%2)
    reason, goals=selection[cfg['task']]
    rows.append(dict(**{**cfg, **ep, 'horizon':stats['horizon']}, episode_completed=True, selection_reason=reason, expected_subgoals=goals, mp4=rel, verification=v, config=str(config.relative_to(root)), log=str((config.parent/'rollout.log').relative_to(root)), stats=str(stats_paths[0].relative_to(root)), **analysis[attempt]))
complete=[r for r in rows if r['episode_completed']]
assert len(complete)==6 and len(rows)==7
assert {r['category'] for r in complete}=={'atomic-seen','composite-seen','composite-unseen'}
assert len({r['task'] for r in complete})==5
summary=dict(task_id='t_5af7225b', versions=version, attempts=rows, completed_episodes=len(complete), construction_failures=len(rows)-len(complete), unique_tasks=len({r['task'] for r in complete}), successes=sum(r['success'] for r in complete), failures=sum(not r['success'] for r in complete), planning_failure_candidates=['kebab-01'], reproduced_planning_failures=[], verification=dict(remote_full_decode=True, local_bytes_and_sha256_match=True, local_decode_not_run=True, explanation='Every remote MP4 was fully decoded in the preserved client image. Local MP4s are byte-identical by SHA256; local native decoder installation was blocked by package-metadata approval checks. Contact sheets were visually inspected.'), limitations=['Exploratory task selection, not benchmark accuracy.', 'Environment seeds fixed; upstream server RNG is not explicitly seeded, so action trajectories are not guaranteed bitwise reproducible.', 'Failure taxonomy is based on external sampled video behavior and source success predicates, not hidden reasoning; no dense subgoal-state trace was captured.', 'Video stride2 and 20fps are upstream defaults; video seconds are playback time, not wall-clock runtime.', 'Inherited upstream observation-space and processor-fps warnings retained in logs.'])
(root/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
lines=['# Xiaomi-Robotics-1 RoboCasa365 rollout exploration','', 'Task t_5af7225b. Actual official Xiaomi policy, parent CUDA12.1 stack, split=target.', '',f"Results: {summary['unique_tasks']} tasks, {len(complete)} completed episodes, {summary['successes']} successes, {summary['failures']} horizon failures. One additional construction failure preserved.",'','## Results and taxonomy','','| Category | Task | Attempt | Actual seed | Steps | Success | End | Taxonomy | MP4 |','|---|---|---|---:|---:|---|---|---|---|']
for r in rows:
    lines.append(f"| {r['category']} | {r['task']} | {r['attempt']} | {r['seed']} | {r['steps']} | {r['success']} | {r['termination_reason']} | {r.get('taxonomy') or '-'} | {r['mp4'] or 'None: construction failed'} |")
lines += ['', '## Planning-failure candidates', '', 'HeatKebabSandwich seed14 (kebab-01): ONE planning-failure candidate, not reproduced. Required baguette is left on plate while the robot proceeds to door/timer. Seed15 fails differently and attempts both foods. No reproduced planning failure is claimed.', '', 'The diagnosis is external behavior analysis, not access to internal model reasoning. Perception/grounding remains a competing explanation for the omitted object.', '', '## Per-attempt evidence']
for r in rows:
    lines += ['', f"### {r['attempt']}: {r['task']}", f"Instruction: {r['instruction']}", f"Diagnosis: {r['diagnosis']}"]
    if r['episode_completed']:
        lines += [f"Selection: {r['selection_reason']}", 'Expected subgoals: '+' -> '.join(r['expected_subgoals']), f"Contact sheet: {str(Path(r['mp4']).with_suffix('.contact.jpg'))}"]
    if 'failure_window_steps' in r: lines += [f"Inspected failure window (approx steps): {r['failure_window_steps']}"]
    lines += [f"Config: {r['config']}", f"Full log: {r['log']}"]
lines += ['', '## Version and validation', '', '```json',json.dumps(version,indent=2),'```', '', 'All six MP4s fully decoded on v4 and copied byte-identically to this directory (SHA256, sizes and frames in video-verification.json). Local file hash verification is performed by build_summary.py. Native local decoding was not run; local package installation was blocked, so playback integrity is established by the full remote decode plus byte identity.', '', 'Simulator source classification: vendor/robocasa/robocasa/utils/dataset_registry.py TARGET_TASKS lines2802-2859; atomic_seen/composite_seen/composite_unseen use official target categories. Task definitions and success predicates are preserved under sources/.', '', 'The initial read-only asset failure is not a failed policy episode. Parent assets were not modified; child volume is writable because official MJCF object construction creates then deletes temporary XML files.', '', '## Reproduce on v4', '', 'Existing verified images, checkpoint and child asset volume must be retained. The stopped server container is retained; restart it rather than running the start command twice. No host port is exposed.', '', '```bash','cd /home/v4/rollouts-xiaomi-t_5af7225b','docker start xiaomi-server-t_5af7225b','docker logs --tail 20 xiaomi-server-t_5af7225b','# Wait until Model loaded / Server running before clients.']
for r in complete:
    lines += [f"bash run-t_5af7225b.sh episode {r['category']} {r['task']} {r['base_seed']} {r['attempt']}-rerun-01"]
lines += ['bash run-t_5af7225b.sh stop','```','','Choose a fresh attempt ID every run; the runner rejects an existing directory. Upstream actual episode seed = base seed + task index within the category (num-trials=1). The manifest records actual seeds, not just CLI base seeds.','','Local integrity check:','```bash','python3 build_summary.py','```','','## Limitations','']+['- '+x for x in summary['limitations']]
(root/'INDEX.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:summary[k] for k in ['unique_tasks','completed_episodes','construction_failures','successes','failures','planning_failure_candidates','reproduced_planning_failures']},indent=2))
print('PASS: expected count/categories, episode metadata, complete frame counts, local MP4 byte sizes and all SHA256 match remote decoded originals.')
