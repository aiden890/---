import json
import time
import torch
import transformers
import flash_attn
from transformers import AutoModel, AutoProcessor

print(json.dumps({'torch':torch.__version__, 'cuda':torch.version.cuda,'transformers':transformers.__version__,'flash_attn':flash_attn.__version__,'gpu':torch.cuda.get_device_name(0),'capability':torch.cuda.get_device_capability(0)}), flush=True)
assert torch.version.cuda == '12.1'
x=torch.randn(1,128,8,64,device='cuda',dtype=torch.bfloat16)
y=flash_attn.flash_attn_func(x,x,x)
torch.cuda.synchronize()
assert y.shape == x.shape and torch.isfinite(y).all()
print('FLASH_ATTN_CUDA_KERNEL_OK', flush=True)
start=time.monotonic()
processor=AutoProcessor.from_pretrained('/checkpoint',trust_remote_code=True,local_files_only=True)
model=AutoModel.from_pretrained('/checkpoint',trust_remote_code=True,local_files_only=True,attn_implementation='flash_attention_2',dtype=torch.bfloat16).cuda().to(torch.bfloat16).eval()
print(json.dumps({'stage':'MODEL_LOADED','seconds':time.monotonic()-start,'vram_allocated':torch.cuda.memory_allocated(),'vram_peak':torch.cuda.max_memory_allocated(),'parameters':sum(p.numel() for p in model.parameters())}),flush=True)
